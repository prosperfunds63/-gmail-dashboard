# Gmail Control Dashboard

A consent-based starter web dashboard for an account owner or an explicitly authorized Gmail delegate. It uses Google's OAuth 2.0 flow and Gmail API; it never asks for or stores a Gmail password.

## Features
- Google sign-in and explicit consent
- View/search message metadata and message bodies
- Compose and send email
- Disconnect session

## Requirements
- Node.js 18+
- A Google Cloud project with the Gmail API enabled
- OAuth 2.0 Web application credentials

## Google setup
1. Open Google Cloud Console and create/select a project.
2. Enable **Gmail API**.
3. Configure the OAuth consent screen and add test users if the app is in Testing.
4. Create an OAuth client ID of type **Web application**.
5. Add this authorized redirect URI exactly: `http://localhost:3000/oauth2callback`
6. Copy `.env.example` to `.env` and enter the client ID, client secret, and a long random `SESSION_SECRET`.

Requested scopes:
- `openid`
- `email`
- `https://www.googleapis.com/auth/gmail.readonly`
- `https://www.googleapis.com/auth/gmail.send`

Google may require app verification before broad public distribution because Gmail scopes are sensitive/restricted. Do not claim verification unless Google has granted it.

## Run locally
```bash
npm install
npm start
```
Visit `http://localhost:3000`.

## Important production hardening
This is a local-development starter, not a production-ready hosted service. Before deployment:
- Use HTTPS and secure, same-site cookies.
- Replace Express's default in-memory session store with a persistent, secure session store.
- Store OAuth refresh tokens encrypted at rest in a managed secret store or encrypted database; do not log tokens.
- Add CSRF protection, rate limits, audit logs, account deletion/revocation, and clear user consent screens.
- Restrict access to the account owner or a formally authorized delegate.
- Publish a privacy policy and complete Google's OAuth verification requirements as applicable.
- Never use this app for covert monitoring or access to another person's Gmail without their informed authorization.

## Scope limits
The app can read and send messages only after the Google account owner grants the requested scopes. It does not monitor keystrokes, capture passwords, bypass Google security, or silently access accounts.
