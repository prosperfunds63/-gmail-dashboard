const $ = id => document.getElementById(id);
async function api(url, options={}) {
  const r = await fetch(url, { ...options, headers: { "Content-Type":"application/json", ...(options.headers||{}) }});
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "Request failed");
  return data;
}
async function status() {
  try {
    const s = await api("/api/status");
    $("connect").hidden = s.connected;
    $("app").hidden = !s.connected;
    $("logout").hidden = !s.connected;
    if (s.connected) { $("email").textContent = s.email; await loadMessages(); }
  } catch(e) { $("connect").hidden = false; $("app").hidden = true; }
}
async function loadMessages() {
  $("messages").textContent = "Loading…";
  try {
    const q = encodeURIComponent($("search").value.trim());
    const data = await api("/api/messages?q="+q);
    $("count").textContent = `${data.messages.length} messages`;
    $("messages").innerHTML = "";
    if (!data.messages.length) $("messages").textContent = "No messages found.";
    data.messages.forEach(m => {
      const el = document.createElement("div"); el.className="mail";
      const from = document.createElement("strong"); from.textContent=m.from;
      const subject = document.createElement("div"); subject.textContent=m.subject;
      const small = document.createElement("small"); small.textContent=(m.date||"")+" · "+m.snippet;
      el.append(from,subject,small); el.onclick=()=>openMessage(m.id); $("messages").append(el);
    });
  } catch(e) { $("messages").textContent=e.message; }
}
async function openMessage(id) {
  $("body").textContent="Loading…";
  try {
    const m=await api("/api/messages/"+encodeURIComponent(id));
    $("subject").textContent=m.subject||"(no subject)";
    $("meta").textContent=`From: ${m.from} | To: ${m.to} | ${m.date}`;
    $("body").textContent=m.body||m.snippet||"(No plain-text body available)";
  } catch(e) {$("body").textContent=e.message;}
}
$("refresh").onclick=loadMessages;
$("search").addEventListener("keydown",e=>{if(e.key==="Enter")loadMessages()});
$("sendForm").onsubmit=async e=>{
  e.preventDefault(); $("sendStatus").textContent="Sending…";
  try {
    await api("/api/send",{method:"POST",body:JSON.stringify({to:$("to").value,subject:$("subjectInput").value,body:$("message").value})});
    $("sendStatus").textContent="Email sent."; $("sendForm").reset();
  } catch(err) {$("sendStatus").textContent=err.message;}
};
$("logout").onclick=async()=>{await api("/api/logout",{method:"POST"});location.reload()};
status();
