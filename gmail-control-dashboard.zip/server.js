require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const { google } = require("googleapis");

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET ||
    !process.env.GOOGLE_REDIRECT_URI || !process.env.SESSION_SECRET) {
  console.error("Missing OAuth/session environment variables. Copy .env.example to .env and fill it in.");
  process.exit(1);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(session({
  name: "gmaildash.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 1000
  }
}));
app.use(express.static("public"));

const oauthClient = () => new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

function gmailFor(req) {
  if (!req.session.tokens) return null;
  const auth = oauthClient();
  auth.setCredentials(req.session.tokens);
  auth.on("tokens", tokens => {
    req.session.tokens = { ...req.session.tokens, ...tokens };
  });
  return google.gmail({ version: "v1", auth });
}
function requireAuth(req, res, next) {
  if (!req.session.tokens) return res.status(401).json({ error: "Connect the account owner's Gmail first." });
  next();
}
function decodeBody(data = "") {
  return Buffer.from(data.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
}
function header(headers = [], name) {
  return headers.find(h => h.name.toLowerCase() === name.toLowerCase())?.value || "";
}
function extractText(payload) {
  if (!payload) return "";
  if (payload.body?.data) return decodeBody(payload.body.data);
  for (const part of (payload.parts || [])) {
    const found = extractText(part);
    if (found) return found;
  }
  return "";
}

app.get("/auth/google", (req, res) => {
  const url = oauthClient().generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    scope: [
      "openid",
      "email",
      "https://www.googleapis.com/auth/gmail.readonly",
      "https://www.googleapis.com/auth/gmail.send"
    ],
    state: require("crypto").randomBytes(24).toString("hex")
  });
  req.session.oauthState = new URL(url).searchParams.get("state");
  res.redirect(url);
});

app.get("/oauth2callback", async (req, res) => {
  try {
    if (!req.query.state || req.query.state !== req.session.oauthState) {
      return res.status(400).send("OAuth state check failed. Please restart sign-in.");
    }
    delete req.session.oauthState;
    if (req.query.error) return res.status(400).send("Google authorization was not completed.");
    const { tokens } = await oauthClient().getToken(String(req.query.code));
    req.session.tokens = tokens;
    res.redirect("/");
  } catch (e) {
    console.error("OAuth callback failed:", e.message);
    res.status(500).send("Could not complete Google authorization.");
  }
});

app.get("/api/status", async (req, res) => {
  if (!req.session.tokens) return res.json({ connected: false });
  try {
    const gmail = gmailFor(req);
    const profile = await gmail.users.getProfile({ userId: "me" });
    res.json({ connected: true, email: profile.data.emailAddress });
  } catch {
    req.session.tokens = null;
    res.json({ connected: false });
  }
});

app.get("/api/messages", requireAuth, async (req, res) => {
  try {
    const gmail = gmailFor(req);
    const q = String(req.query.q || "").slice(0, 200);
    const list = await gmail.users.messages.list({
      userId: "me", q, maxResults: Math.min(Number(req.query.maxResults) || 20, 50)
    });
    const messages = await Promise.all((list.data.messages || []).map(async item => {
      const r = await gmail.users.messages.get({ userId: "me", id: item.id, format: "metadata",
        metadataHeaders: ["From", "To", "Subject", "Date"] });
      const h = r.data.payload?.headers || [];
      return {
        id: item.id,
        threadId: r.data.threadId,
        from: header(h, "From"),
        to: header(h, "To"),
        subject: header(h, "Subject") || "(no subject)",
        date: header(h, "Date"),
        snippet: r.data.snippet || ""
      };
    }));
    res.json({ messages });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: "Unable to load messages." });
  }
});

app.get("/api/messages/:id", requireAuth, async (req, res) => {
  try {
    const gmail = gmailFor(req);
    const r = await gmail.users.messages.get({ userId: "me", id: req.params.id, format: "full" });
    const h = r.data.payload?.headers || [];
    res.json({
      id: r.data.id, from: header(h, "From"), to: header(h, "To"),
      subject: header(h, "Subject"), date: header(h, "Date"),
      body: extractText(r.data.payload).slice(0, 30000),
      snippet: r.data.snippet || ""
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: "Unable to open this message." });
  }
});

app.post("/api/send", requireAuth, async (req, res) => {
  const { to, subject, body } = req.body || {};
  if (![to, subject, body].every(v => typeof v === "string") || !to.trim() || !body.trim()) {
    return res.status(400).json({ error: "Recipient and message are required." });
  }
  if (to.length > 500 || subject.length > 500 || body.length > 20000) {
    return res.status(400).json({ error: "Message is too long." });
  }
  try {
    const gmail = gmailFor(req);
    const profile = await gmail.users.getProfile({ userId: "me" });
    const from = profile.data.emailAddress;
    const rawMessage = [
      `From: ${from}`, `To: ${to}`, `Subject: ${subject.replace(/[\r\n]/g, " ")}`,
      "MIME-Version: 1.0", 'Content-Type: text/plain; charset="UTF-8"',
      "Content-Transfer-Encoding: 7bit", "", body
    ].join("\r\n");
    const raw = Buffer.from(rawMessage).toString("base64url");
    const result = await gmail.users.messages.send({ userId: "me", requestBody: { raw } });
    res.json({ sent: true, id: result.data.id });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: "Gmail could not send the message." });
  }
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.listen(PORT, () => console.log(`Gmail dashboard running at http://localhost:${PORT}`));
